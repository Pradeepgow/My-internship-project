<?php

namespace App\Query\Blog\Post\Comment\Find;

class FindCommentsQuery
{

}