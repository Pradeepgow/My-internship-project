<?php

namespace App\Query\Blog\Post\Find;

class FindPostsQuery
{

}