<?php

namespace App\Query\Blog\Post;

class GetPostStatusesQuery
{

}