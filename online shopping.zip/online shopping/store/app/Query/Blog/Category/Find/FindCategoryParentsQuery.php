<?php

namespace App\Query\Blog\Category\Find;

class FindCategoryParentsQuery
{

}