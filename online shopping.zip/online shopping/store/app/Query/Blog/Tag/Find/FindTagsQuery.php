<?php

namespace App\Query\Blog\Tag\Find;

class FindTagsQuery
{

}