<?php

namespace App\Query\Page\Find;

class FindPagesQuery
{

}