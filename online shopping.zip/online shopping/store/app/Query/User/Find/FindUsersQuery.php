<?php

namespace App\Query\User\Find;

class FindUsersQuery
{

}