<?php

namespace App\Query\User;

class GetUserRolesQuery
{

}