<?php

namespace App\Query\Region\Find;

class FindRegionsListQuery
{

}