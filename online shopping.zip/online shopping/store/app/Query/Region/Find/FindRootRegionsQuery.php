<?php

namespace App\Query\Region\Find;

class FindRootRegionsQuery
{

}