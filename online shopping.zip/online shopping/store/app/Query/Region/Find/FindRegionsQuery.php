<?php

namespace App\Query\Region\Find;

class FindRegionsQuery
{

}