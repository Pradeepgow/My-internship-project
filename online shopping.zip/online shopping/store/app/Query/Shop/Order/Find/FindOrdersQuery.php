<?php

namespace App\Query\Shop\Order\Find;

class FindOrdersQuery
{

}