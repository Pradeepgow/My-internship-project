<?php

namespace App\Query\Shop\Product\Find;

class FindProductsQuery
{

}