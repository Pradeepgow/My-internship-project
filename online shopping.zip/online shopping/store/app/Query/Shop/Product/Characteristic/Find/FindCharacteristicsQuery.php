<?php

namespace App\Query\Shop\Product\Characteristic\Find;

class FindCharacteristicsQuery
{

}