<?php

namespace App\Query\Shop\Product;

class GetProductStatusesQuery
{

}