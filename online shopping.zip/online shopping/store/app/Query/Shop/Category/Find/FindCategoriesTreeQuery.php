<?php

namespace App\Query\Shop\Category\Find;

class FindCategoriesTreeQuery
{

}