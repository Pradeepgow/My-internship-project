<?php

namespace App\Query\Shop\Review\Find;

class FindReviewsQuery
{

}