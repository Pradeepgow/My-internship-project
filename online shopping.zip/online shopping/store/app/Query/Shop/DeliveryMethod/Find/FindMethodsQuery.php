<?php

namespace App\Query\Shop\DeliveryMethod\Find;

class FindMethodsQuery
{

}