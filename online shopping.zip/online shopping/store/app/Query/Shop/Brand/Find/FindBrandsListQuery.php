<?php

namespace App\Query\Shop\Brand\Find;

class FindBrandsListQuery
{

}