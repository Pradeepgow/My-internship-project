<?php

namespace App\Query\Shop\Comment\Find;

class FindCommentsQuery
{

}