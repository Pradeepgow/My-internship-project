<?php

namespace App\Query\Shop\Characteristic\Characteristic;

class GetTypesListQuery
{

}