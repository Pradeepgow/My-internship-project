<?php

namespace App\Query\Shop\Characteristic\Characteristic\Find;

class FindCharacteristicsQuery
{

}