<?php

namespace App\Query\Newsletter\Email\Find;

class FindEmailsQuery
{

}